<?php
/**
 * The template for displaying product-singular.php
 *
 * @package WordPress
 * @subpackage lustria
 * @since lustria 1.0
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_GSF_Product_Singular extends G5P_ShortCode_Base {
}
