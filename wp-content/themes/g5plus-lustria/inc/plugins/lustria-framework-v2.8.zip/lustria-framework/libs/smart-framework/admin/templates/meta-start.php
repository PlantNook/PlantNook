<?php /** @var array $list_section */?>
<div class="gsf-meta-box-wrap">
	<div class="gsf-meta-box-wrap-inner">
		<?php GSF()->helper()->getTemplate('admin/templates/meta-section', array('list_section' => $list_section)); ?>
		<div class="gsf-meta-box-fields-wrapper">
			<div class="gsf-meta-box-fields">